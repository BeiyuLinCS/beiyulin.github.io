   // for(int i= 0; i< k; i++){
    //     cout << e[i].name << ", " << e[i].id << ", " << e[i].kpi << ", " << endl;
    // }