#include <iostream>
#include <cmath>
#include <string>
#include <fstream>
using namespace std;
enum phoneType { HOME, WORK, MOBILE, ADDITIONAL};


int main()
{
    // ifstream fin2; // ifstream: input file stream
    // int num;
    // // fin: readin file name 
    // // fout: file name to write the data to
    // num = 2; 
    // fin2.open("input2.txt");

    // if (!fin2.eof()) 
    // {cout << "the file is not empty." << endl;}

    // int data;           // file contains an undermined number of integer values
    // ifstream fin;     // declare stream variable name

    // // end of the file
    // // double check: eof is hard to use.
    // // while(!a.eof()){
    // //     cout << "count" << count << endl;
    // //     count++;
    // // }

    // string nums;

    // while(getline(fin2, nums))
    // {
    //     cout << nums << endl;
    // }
    // fin2.close();

    // // write data into the file (write: overwrite everything in the file)
    // ofstream fout;  // ofstream: output file stream 
    // fout.open("input2.txt"); // overwrite everything in input2.txt file.
    // fout << "today is tuesday." << endl;
    // fout.close();

    // // append the data into the current file. 
    // ofstream fout_app;
    // fout_app.open("input2.txt", ios::app);
    // int n = 0;
    // while(n< 5){
    //     fout_app << "append a new line" << endl;
    //     cout << "n " << n << endl;
    //     n++;
    // }
    
    // fout_app.close();

    // read in data from the input1.txt
    ifstream fin1; 
    fin1.open("input1.txt");
    string read_data_f1;
    while(getline(fin1, read_data_f1)){
        cout << read_data_f1 << endl;
    }
    fin1.close();

    // write out one sentence "hello world" into input1.txt
    ofstream fout1; 
    fout1.open("input1.txt");
    fout1 << "hello world again" << endl;
    fout1.close();

    // append "hello world" once into the file input3.txt
    ofstream fout3;
    fout3.open("input3.txt", ios::app);
    fout3 << "hello world" << endl;
    fout3.close();












    return 0;
}



