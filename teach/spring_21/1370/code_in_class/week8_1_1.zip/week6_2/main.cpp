#include <iostream>
#include <cmath>
#include <string>
#include <fstream>
using namespace std;

int main()
{
    ifstream fin1, fin2, fin3;
    int num;
    // fin: readin file name 
    // fout: file name to write the data to
    num = 2; 
    fin2.open("input2.txt");
    if (!fin2.eof()) 
    {cout << "the file is not empty." << endl;}

    int data;           // file contains an undermined number of integer values
    ifstream fin;     // declare stream variable name



    // end of the file
    // double check: eof problem
    // while(!a.eof()){
    //     cout << "count" << count << endl;
    //     count++;
    // }

    string nums;

    while(getline(fin2, nums))
    {
        cout << nums << endl;
    }
    fin2.close();

    // write data into the file (write: overwrite everything in the file)
    ofstream fout;
    fout.open("input2.txt");
    fout << "today is tuesday." << endl;
    fout.close();

    // append the data into the current file. 
    ofstream fout_app;
    fout_app.open("input2.txt", ios::app);
    int n = 0;
    while(n< 5){
        fout_app << "append a new line" << endl;
        cout << "n " << n << endl;
        n++;
    }
    
    fout_app.close();


    return 0;
}



