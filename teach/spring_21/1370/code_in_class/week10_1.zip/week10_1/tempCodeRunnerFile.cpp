#define NDEBUG
// #include <cassert>