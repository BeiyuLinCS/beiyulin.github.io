#include <iostream>
using namespace std; // std: standard

int main()
{
    // variables
    // 1. declare a variable;
    int num; // num <=> number
    // 2. assign values to the variable; use the variable
    num = 2;
    // << insertion operator
    // cout << num << endl;

    // input statement 
    // string x;
    // cout << "please input a string " << endl;
    // cin >> x;
    // cout << endl;
    // cout << "The input string is " << x << endl;

    // 1. declare variables;
    int x, y;
    char ch; 
    cout << "please input the vaules for x, ch, y" << endl;
    cin >> x >> ch >> y ; 
    cout << "the x value is " << x << endl;
    cout << "the y value is " << y <<  endl;
    cout << "the ch value is " << ch <<  endl;
    

    // 1. declare a variable
    int i_ada123;
    int _12dfaa;
    int 1_dafe;
    int 1dafea;
    int var_temp1;
    int var_temp2;

    // two default tpyes. 
    int var_temp3;
    int varTemp3;
    



}

