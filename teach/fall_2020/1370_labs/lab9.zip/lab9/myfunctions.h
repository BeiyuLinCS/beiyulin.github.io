//************************  Function definitions  *************************
// Read the handout carefully for detailed description of the functions that you have to implement

// round_off(): Rounds the value received in the first parameter to the number of digits received in the second parameter


// getData(): Gets two lengths from the keyboard and returns them to the caller


// printData(): Receives the output file, base of the rectangle, height of the rectangle, area of the rectangle,
// radius a of the ellipse, radius b of the ellipse, and area of the ellipse and prints the output to the file



// area_rectangle(): Calculates the area of the rectangle and returns it rounded to 1 decimal digit to the caller


// area_ellipse(): Calculates the area of the area_ellipse and returns it rounded to 1 decimal digit to the caller



