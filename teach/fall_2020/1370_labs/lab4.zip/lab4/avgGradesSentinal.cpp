/////////////////////////////////////////////////////////////////////
//
// Name: <Put your name here>
// Date: <Today's Date>
// Class: <Your class number and section number, like: CSCI 1370.02>
// Semester: <This semester, like: Spring 2012>
// CSCI/CMPE 1370 Instructor: <Your lecture instructor's name>
//
// Use a sentinal controlled loop to find the average of grades
// entered by the user. The sentinal value is -1.
//
//////////////////////////////////////////////////////////////////////

#include <iostream>
#include <string>
using namespace std;

int main()
{
    int grade; // The grade entered by the user
    int sum; // Sum of the grades
    int count; // Number of grades entered
    double avg; // Average of the grades
    
    
    ////////////////////////////////
    // Start of your code
    
    
    // Loop until the user enters -1
    // Each time through the loop, add the number input by the user
    // to the sum. Make sure not to include the sentinal value in the
    // sum or count!
   
    
    
    
    
    // Find the average of the grades entered by the user
    // and print the result

    
    
    
    // End of your code
    ////////////////////////////////

    system("pause");

    return 0;
}
