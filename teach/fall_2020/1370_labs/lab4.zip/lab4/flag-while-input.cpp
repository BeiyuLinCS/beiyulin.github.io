/////////////////////////////////////////////////////////////////////
//
// Name: <Put your name here>
// Date: <Today's date>
// Class: <Your class number and section number, like: CSCI 1370.02>
// Semester: <This semester, like: Spring 2012>
// CSCI/CMPE 1370 Instructor: <Your lecture instructor's name>
//
// Use looping to ensure that the user inputs a proper value.
//
//////////////////////////////////////////////////////////////////////

#include <iostream>
#include <string>
using namespace std;

int main()
{
    char ans; // The user's answer to the question
    int age; // The user's age
    bool correct; // The boolean flag

    
    
    ////////////////////////////////
    // Beginning of your code
    
    
    // Ask the user a yes/no question and make sure the response is
    // either y or n

    
    
    
    
    
    // Get the user's age
    // Make sure the user enters her age as a number
    
    
    
    
    

    // End of your code
    ////////////////////////////////
    
    cout << "Thanks for your input!" << endl;
    

    system("pause");
    
    return 0;
}
