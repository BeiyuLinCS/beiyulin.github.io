#include <iostream>
using namespace std;

int main()
{
    // cout << "Value of myVar: " << myVar << endl;
    // myVar = 'Z';
    // cout << "Value of myVar: " << myVar;
    // return 0;
    // cout<<44;
    // int temp;
    // temp = 44;
    // cout << temp;
    // cout << endl;

    //allocate memory for a VARIABLE
    int xTemp;  // define the type (int) and give a variable name (x)
    xTemp = 7;  // in the computer, the memory stored the address of the variable x and value of the variable x;
    // lhs (left-hand side) = rhs (right-hand side)
    cout << "xTemp + 7"; //print out a value of the operation or just the operation. 
    // " " in programming language represents a string. 
    // the computer will print out whatever in the "". 

    // two types of variable name: connected by _; use Captiliazed first letter between two words
    // but not connected by +, -, ... 
    // x_temp or xTemp or xtemp (all these three are different variable names); x temp (not good. no space in between please.)
    // _temp (okay) or temp_good_example (okay); 1_temp (not good)
    // temp_1 or temp1 

    // print out the value of the variable xTemp on console/terminal 
    // each sentence here is a statement (on Monday's lecture)
    // cout << 100; 

    // example of overwrite the value of a variable. 
    // int x;
    // x = 5; 
    // cout << "first value of x: "<< x << endl;  // endl: start a new line
    // x = 6;
    // cout << "second value of x: " << x << endl;
    // x = x+10;
    // cout << "addtion value of x: " << x << endl;

    // int x;
    // int y;

    // cout << “Hello”;
    // cout << endl;
    // x = 1 + 4 – 3;
    // cout << x; // print out the x value is 2.
    // cout << endl;
    // y = x – 1; // assign 1 to the variable y

    // // for any assignment, we do the rhs first (y + 5 => 6)
    // // and then, we assign the rhs value 6 to the left hand side.
    // y = y + 5; // assign 6 to the variable on lhs y
    // cout << y;
    // cout << endl;


}
