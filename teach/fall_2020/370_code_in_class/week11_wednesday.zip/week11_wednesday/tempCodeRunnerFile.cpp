 // Employee employee_data[6]; // create an array object (default initialization is already called.)
    // read_from_file("google_employee.txt", employee_data);

    // for(int i = 0; i< 4; i++){
    //     cout << employee_data[i].name << " " << employee_data[i].position << " " << employee_data[i].kpi << " " << endl;
    // }