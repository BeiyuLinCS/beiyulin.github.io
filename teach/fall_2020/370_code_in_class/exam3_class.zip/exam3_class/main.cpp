#include <iostream>
using namespace std;

// main function: in any c++/c/python, there is always one and only one main function.
// main function do not need to declare.
// since this is the only function that is used to connect us with the everything in the c++ system.


// declare a function: prototype function_name(function_input);
// function_input can be empty;
// when we name a function/variable, please avoid the system default name;
int add1();

int main()
{ /****************** read in one input ******************/
    // allocate memory for variables
    int number;

    // cout: print out the results/sentecnes on console/terminal.
    cout << "hello world!" << endl;

    // cin: read in data from the keyboard/console/terminal
    cout << "please input a number for this task" << endl;
    cin >> number;
    cout << "the readin number is: " << number << endl;

    // case 1: if we input a sequence of numbers that are separated by space
    // only to one variable
    // results: the program/system only read in one data/number
    // 23 45: two numbers
    // work for me: summary the ways that separate two numbers: space _ ; ,
    // for the string type, the only way to separate two strings is using space.

    /****************** read in multiple inputs (same type) together ******************/
    // allocate memory for variables before we use it.
    string num1, num2;

    // // endl: start a new line
    cout << "hello world!" << endl << "Today is wednesday" << endl;

    cout << "please input two strings" << endl;
    cin >> num1 >> num2; 
    // cout << num1 << endl<< num2 << endl;
    cout << "the first string readin is : " << num1 << endl;
    cout << "the second string readin is : " << num2 << endl;

    /****************** read in multiple inputs (different types) together ******************/
    double u;
    string v;

    // cout << "please input a float number and then input a string" <<endl;
    // cin >> u >> v;
    // cout << "the readin float number is: " << u << endl;
    // cout << "the readin string is: " << v << endl;
    cin >> u;
    // cin >> u >> "dafa"; // will have errors, since the the input is from the keyboard. 
    
    // print out multiple items with different types. 
    cout << u << endl << "dafa" << endl;

    /****************** basic function ******************/
    // call a function
    int sum_result, mul_result;
    sum_result = add1();
    cout << "the sum of these two numbers after calling the function is: " << sum_result << endl;
    
}

// use/devleop a function AFTER declared
// declare a function always BEFORE using it. similar as using a varibale
int add1(){
    cout << "inside of the add1 funtion" << endl;
    // allocate the memory for variables;
    int num1, num2, sum;

    cout << "please input two integers" << endl;
    cin >> num1 >> num2;
    sum = num1 + num2;
    // cout << "the addition of these two numbers are: " << sum << endl;

    // any function we defined, must have a return.
    return sum;
}

