#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    // infinite loop
    // break: jump out of the entire loop. 

    while (1) {
        cout << "this would never stop!" << endl;
        break;
    }
    cout << "out of the while loop." << endl;
    cout << endl;
    cout << endl;

    int num;
    while (1)
    {
        cout << "Please input an integer!" << endl;
        cin >> num;

        if (num == 5){
            break;
        }   
    }

    int i = 0;
    while (i < 6){
        cout << "a very simple while loop" << endl;
        i++; // step is 1. 
    }

    // while: run 0 times; do...while: at least 1 time; 
    // 'for' loop
    /** for (start_value_index; end_value_index; step){
     * cout << "whatever inside of the for loop" << endl;
    } **/

    int j;  // allocate memory for a varaible named j;
    cout << "this is a very simple example of for loop" << endl;
    for (j = 0; j < 6; j = j+2){
        cout << j << endl;
    }

    // nested for loop
    // if I have two people who are taking 5 classes. 
    // I want to input their grades via keyboard. 
    // Mary, Roberte;
    // math, computer science, speech, physics, philosophy.

    int k, l;
    int grade;
    int sum_var, average_var; // when we define a variable name, try to avoid the name that the system already defined. 
    // k < 2 (2 iterations) instead of <= 2 (3 iterations);
    sum_var = 0;
    average_var = 0;

    for (k = 0; k <2; k++)
    {
        sum_var = 0;
        cout << "this is for student " << k+1 << endl;
        cout << "please input the grades of five courses of this student" << endl;
        for(l=0; l<5; l++){    
            cin >> grade;
            sum_var = sum_var + grade;
        }
        average_var = sum_var/5.0; // the data type on the right side will be converted to the left (please review the previous slides)
        cout << "the average grade is " << average_var << endl;
        // 5/3 => 1; 3/4 => 0; 3/4.0 => 0.75
        cout << endl;
        cout << endl;
    }

    // example of the nested loop on slide number 9 
    // five row <=> 5 iterations
    for (i=0; i<5; i++){
        for(j=0; j <= i; j++){
            cout << "*";
        }
        cout << endl;
    }

    //*
    // **
    // ***
    // ****
    // *****

    /** line 78 i = 0, go to the line 79: j is betwwen [0, i=0] <=> the for loop for j will do 1 iteration => '*' 
     * line 78 i = 1, go to the line 79: j is betwwen [0, i=1] <=> the for loop for j will do 2 iteration => j = 0, print out "*" ; j = 1, add a new "*" that is concatenate to the previous "*" => "**"
     * line 78 i = 2, go to the line 79: j is betwwen [0, i=2] <=> the for loop for j will do 3 iteration => j = 0, print out "*" ; j = 1, add a new "*" that is concatenate to the previous "*" => "**"; j = 2, "***"
     * 
     **/



        

}





