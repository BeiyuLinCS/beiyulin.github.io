
    cout << "the data for employee_data0" << endl;
    cout << employee_data0.name << " " << employee_data0.position << " " << employee_data0.kpi << endl;
    cout << endl;