#include <iostream>
using namespace std;

int main()
{
    char y;
    y = 'a'; // single quote for the character; 
    cout<<y << endl;

    bool Monday;
    bool Tuesday;
    Monday = true;
    Tuesday = false;
    // cout << Monday % Tuesday << endl; // % does not work for the bool type data. 

    int a;
    int b;
    a = 7;
    b = 4;
    cout << a%b << endl; // % only works for integer type. 

    // let see other integral type of %

    char c;
    char d;
    c = 'x';
    d = 'y';
    cout << c%d <<endl; // I will talk about how the char do the module;
    // char can be stored as a binary (32 bits); % over the 32 bits 

    // short int nums;
    // nums = 327670000000; // the number is out of the range of the short int type. 
    // cout << nums <<endl;
    // cout << nums + 1 << endl;


    // slide number 18; when definig a variable, 
    // the variable name can not be started with an number/digit;
    // start with a letter or _
    int slide18_1 = 8;
    int slide18_2 = 18;
    float sldie18_3;
    sldie18_3 = 2 + 3.0123 * 5; // the type from the right side will 
    // be converted to the type on the left side; 
    // some default set in c++ I will double check.

    // one concern: if the float type variable assigned a float with only zeros,
    // it may not printout the zeros ( it will look like an integer on the console).

    // promote the datatype from integer to float
    cout << 2 + 3.0123 * 5 << endl;

    // promote the char into integer;
    cout << 'a' + 23 << endl;
    // covert the character 'a' => binary type b1
    // covert the 23 => binary type b2
    // b1 + b2 converted into an integer

    // convert the type from the right to the left
    // example of slide 21
    char left_variable;
    int right_variable = 111;
    left_variable = right_variable;
    cout << left_variable << endl;
}
